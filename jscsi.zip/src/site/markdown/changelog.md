<a href="https://github.com/disy/jSCSI"><img style="position: absolute; top: 0; right: 0; border: 0;" src="https://s3.amazonaws.com/github/ribbons/forkme_right_green_007200.png" alt="Fork me on GitHub"/></a>

#Changelog:

##2.5.2

* Available as OSGI-module
* minor bugfixes in target

##2.5

* Easier interface to different Storages within target
* Beta-integration of jclouds as backend for jSCSI

##2.3

* Blackbox-Tests for Initiator and Target
* Whitebox-Tests for Target
* Target verified against Linux iSCSI Initiator and Windows 8 Initiator

##2.2

* Minor bugfixes in target

##2.1

* Implementation in target
* Splitting the initiator in commons and initiator-bundles
* Minor bugfixes in initiator

##2.0

* Initiator refactored
* Initiator: MC/S capable

##1.0

* Initiator plain, single threaded
