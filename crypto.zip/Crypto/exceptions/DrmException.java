package cz.mit_consulting.exceptions;

public class DrmException extends Exception {

    public DrmException() {
    }

    public DrmException(final String msg) {
        super(msg);
    }
}
