package cz.mit_consulting.exceptions.crypto;

public class CreateKeyStoreException extends CryptographyException {

    public CreateKeyStoreException(final String msg) {
        super(msg);
    }
}
