package cz.mit_consulting.exceptions.crypto;


import cz.mit_consulting.exceptions.DrmException;

public class CryptographyException extends DrmException {

    public CryptographyException() {
    }

    public CryptographyException(final String msg) {
        super(msg);
    }
}
