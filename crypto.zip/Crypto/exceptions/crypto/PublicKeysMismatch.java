package cz.mit_consulting.exceptions.crypto;


import cz.mit_consulting.exceptions.DrmException;

public class PublicKeysMismatch extends DrmException {

    public PublicKeysMismatch() {
    }

    public PublicKeysMismatch(final String msg) {
        super(msg);
    }
}
