package cz.mit_consulting.exceptions.crypto;

public class LoadKeysException extends CryptographyException {

    public LoadKeysException(final String msg) {
        super(msg);
    }
}
