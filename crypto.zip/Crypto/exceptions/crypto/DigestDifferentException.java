package cz.mit_consulting.exceptions.crypto;

public class DigestDifferentException extends CryptographyException {

    public DigestDifferentException(final String msg) {
        super(msg);
    }
}
