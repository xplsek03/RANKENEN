package cz.mit_consulting.exceptions.crypto;

public class KeyGenerateException extends CryptographyException {

    public KeyGenerateException(final String msg) {
        super(msg);
    }
}