package cz.mit_consulting.exceptions.crypto;

public class DecriptionException extends CryptographyException {

    public DecriptionException(final String msg) {
        super(msg);
    }
}
