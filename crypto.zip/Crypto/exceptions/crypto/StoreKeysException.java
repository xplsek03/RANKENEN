package cz.mit_consulting.exceptions.crypto;

public class StoreKeysException extends CryptographyException {

    public StoreKeysException(final String msg) {
        super(msg);
    }
}