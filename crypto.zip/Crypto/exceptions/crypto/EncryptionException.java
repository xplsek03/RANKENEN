package cz.mit_consulting.exceptions.crypto;

public class EncryptionException extends CryptographyException {

    public EncryptionException(final String msg) {
        super(msg);
    }
}
