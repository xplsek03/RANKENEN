package cz.mit_consulting.crypto;

import cz.mit_consulting.exceptions.crypto.*;
import cz.mit_consulting.exceptions.filesystem.ZipFilesException;
import cz.mit_consulting.util.Enums;
import cz.mit_consulting.util.OsCheck;
import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.x509.X509V3CertificateGenerator;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Crypto {

    String PATH_TO_JKS = System.getProperty("user.home") + "/DRM_keys.jks";

    private final static java.util.logging.Logger log = Logger.getLogger(Crypto.class.getName());

    public KeyPair generateAsymmetricKeys(String algorithm, int keySize) throws KeyGenerateException {
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance(algorithm);
            keyGen.initialize(keySize);
            return keyGen.generateKeyPair();
        } catch (NoSuchAlgorithmException e) {
            String error = "Cannot generate asymmetric keys: " + e;
            log.log(Level.SEVERE, error);
            throw new KeyGenerateException(error);
        }
    }

    public SecretKey generateSymmetricKey(String algorithm) throws KeyGenerateException {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance(algorithm);
            keyGen.init(128);
            return keyGen.generateKey();
        } catch (NoSuchAlgorithmException e) {
            String error = "Cannot generate symmetric key: " + e;
            log.log(Level.SEVERE, error);
            throw new KeyGenerateException(error);
        }
    }

    public byte[] asymmetricEncrypt(byte[] data, PublicKey publicKey) throws EncryptionException {
        try {
            Cipher cipher = Cipher.getInstance(publicKey.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            return cipher.doFinal(data);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException e) {
            String error = "Cannot asymmetric encrypt data: " + e;
            log.log(Level.SEVERE, error);
            throw new EncryptionException(error);
        }
    }

    public byte[] asymmetricDecrypt(byte[] data, PrivateKey privateKey) throws DecriptionException {
        try {
            Cipher cipher = Cipher.getInstance(privateKey.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            return cipher.doFinal(data);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException e) {
            String error = "Cannot asymmetric decrypt data: " + e;
            log.log(Level.SEVERE, error);
            throw new DecriptionException(error);
        }
    }

    public byte[] symmetricEncrypt(byte[] data, SecretKey secretKey, String cipher) throws EncryptionException {
        try {
            return symetricCrypt(data, secretKey, cipher, Cipher.ENCRYPT_MODE);
        } catch (NoSuchPaddingException | NoSuchAlgorithmException | InvalidAlgorithmParameterException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            String error = "Cannot symmetric encrypt data: " + e;
            log.log(Level.SEVERE, error);
            throw new EncryptionException(error);
        }
    }

    public byte[] symmetricDecrypt(byte[] data, SecretKey secretKey, String cipher) throws DecriptionException {
        try {
            return symetricCrypt(data, secretKey, cipher, Cipher.DECRYPT_MODE);
        } catch (NoSuchPaddingException | NoSuchAlgorithmException | InvalidAlgorithmParameterException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            String error = "Cannot symmetric decrypt data: " + e;
            log.log(Level.SEVERE, error);
            throw new DecriptionException(error);
        }
    }

    private byte[] symetricCrypt(byte[] data, SecretKey secretKey, String cipher, int cryptMode) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher symetricCipher = Cipher.getInstance(cipher);
        byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        symetricCipher.init(cryptMode, secretKey, new IvParameterSpec(iv));
        return symetricCipher.doFinal(data);
    }

    public HybridEncryptPair hybridEncrypt(byte[] data, PublicKey publicKey, SecretKey secretKey, String cipher) throws EncryptionException {
        byte[] encryptedSecretKey = asymmetricEncrypt(secretKey.getEncoded(), publicKey);
        //TODO metadata
        byte[] encryptedData = symmetricEncrypt(data, secretKey, cipher);
        return new HybridEncryptPair(encryptedData, null, encryptedSecretKey);
    }

    public DecryptedPair hybridDecrypt(PrivateKey privateKey, HybridEncryptPair hybridEncryptPair, String cipher, String encryptionAlgorithm) throws DecriptionException {
        byte[] decryptedSecretKey = asymmetricDecrypt(hybridEncryptPair.getEncryptedKey(), privateKey);
        return new DecryptedPair(symmetricDecrypt(hybridEncryptPair.getData(), new SecretKeySpec(decryptedSecretKey, 0, decryptedSecretKey.length, encryptionAlgorithm)
                , cipher), hybridEncryptPair.getMetadata());
    }

    public PublicKey getPublicKey(byte[] key, String encryptionAlgorithm) throws CryptographyException {
        try {
            byte[] publicBytes = Base64.decodeBase64(key);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
            KeyFactory keyFactory = KeyFactory.getInstance(encryptionAlgorithm);
            return keyFactory.generatePublic(keySpec);
        } catch (InvalidKeySpecException | NoSuchAlgorithmException e) {
            String error = "Cannot get public key: " + e;
            log.log(Level.SEVERE, error);
            throw new CryptographyException(error);
        }
    }

    public PrivateKey getPrivateKey(byte[] key, String encryptionAlgorithm) throws CryptographyException {
        try {
            byte[] privateBytes = Base64.decodeBase64(key);
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateBytes);
            KeyFactory keyFactory = KeyFactory.getInstance(encryptionAlgorithm);
            return keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException | NoSuchAlgorithmException e) {
            String error = "Cannot get private key: " + e;
            log.log(Level.SEVERE, error);
            throw new CryptographyException(error);
        }
    }

    public void storeKeysToKeystore(KeyPair keyPair, String userEmail, String password) {
        try {
            OsCheck.OSType ostype = OsCheck.getOperatingSystemType();
            switch (ostype) {
                case Windows:
                    storeToWindowsKeystore(keyPair, userEmail);
                    break;
                case MacOS:
                    break;
                case Linux:
                    storeToJavaKeystore(keyPair, password, userEmail);
                    break;
                case Other:
                    break;
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    private void storeToWindowsKeystore(KeyPair keyPair, String userEmail) throws StoreKeysException {
        try {
            java.security.cert.Certificate certificate = generateCertificate(keyPair);
            KeyStore keyStore = KeyStore.getInstance(Enums.KeyStore.WINDOWS.getValue());
            keyStore.load(null, null);
            java.security.cert.Certificate[] certChain = new Certificate[1];
            certChain[0] = certificate;
            keyStore.setCertificateEntry("DRM_" + userEmail + "_public_key", certificate);
            keyStore.setKeyEntry("DRM_" + userEmail + "_private_key", keyPair.getPrivate(), null, certChain);
            keyStore.store(null, null);
            log.info("Keys stored successfully.");
        } catch (Throwable e) {
            String error = "Cannot store keys: " + e;
            log.log(Level.SEVERE, error);
            throw new StoreKeysException(error);
        }
    }

    public void storeToJavaKeystore(KeyPair keyPair, String password, String userEmail) throws CreateKeyStoreException, StoreKeysException {
        File ks = new File(PATH_TO_JKS);
        if (!ks.exists()) {
            try {
                KeyStore keyStore = KeyStore.getInstance("PKCS12");
                keyStore.load(null, null);
                keyStore.store(new FileOutputStream(PATH_TO_JKS), password.toCharArray());
                log.info("Keystore created successfully at " + ks.getPath());
            } catch (Exception e) {
                String error = "Cannot create key store: " + e;
                log.log(Level.SEVERE, error);
                throw new CreateKeyStoreException(error);
            }
        }
        try {
            KeyStore keyStore = KeyStore.getInstance(Enums.KeyStore.JKS.getValue());
            keyStore.load(new FileInputStream(PATH_TO_JKS), password.toCharArray());
            X509Certificate cert = generateCertificate(keyPair);
            X509Certificate[] chain = new X509Certificate[1];
            chain[0] = cert;
            keyStore.setKeyEntry("DRM_" + userEmail + "_private_key", keyPair.getPrivate(), password.toCharArray(), chain);
            keyStore.setCertificateEntry("DRM_" + userEmail + "_public_key", cert);
            keyStore.store(new FileOutputStream(PATH_TO_JKS), password.toCharArray());
            log.info("Keys stored successfully.");
        } catch (Exception e) {
            String error = "Cannot store keys: " + e;
            log.log(Level.SEVERE, error);
            throw new StoreKeysException(error);
        }
    }

    public KeyPair loadKeys(String userEmail, String password) throws LoadKeysException {
        try {
            OsCheck.OSType ostype = OsCheck.getOperatingSystemType();
            FileInputStream fis = null;
            Enums.KeyStore keyStoreType = Enums.KeyStore.WINDOWS;
            if (ostype != OsCheck.OSType.Windows) {
                String path = System.getProperty("user.home") + "/DRM_keys.jks";
                fis = new FileInputStream(path);
                keyStoreType = Enums.KeyStore.JKS;
            }
            KeyStore keyStore = KeyStore.getInstance(keyStoreType.getValue());
            keyStore.load(fis, password.toCharArray());  // Load keystore
            final Key key = keyStore.getKey("DRM_" + userEmail + "_private_key", password.toCharArray());
            if (key == null) {
                return null;
            }
            final Certificate cert = keyStore.getCertificate("DRM_" + userEmail + "_private_key");
            final PublicKey publicKey = cert.getPublicKey();
            return new KeyPair(publicKey, (PrivateKey) key);
        } catch (Exception e) {
            String error = "Cannot load keys: " + e;
            log.log(Level.SEVERE, error);
            throw new LoadKeysException(error);
        }
    }

    public X509Certificate generateCertificate(KeyPair keyPair) throws NoSuchAlgorithmException, CertificateEncodingException, NoSuchProviderException, InvalidKeyException, SignatureException {
        X509V3CertificateGenerator cert = new X509V3CertificateGenerator();
        cert.setSerialNumber(BigInteger.valueOf(1));   //or generate a random number
        cert.setSubjectDN(new X509Principal("CN=localhost"));  //see examples to add O,OU etc
        cert.setIssuerDN(new X509Principal("CN=localhost")); //same since it is self-signed
        cert.setPublicKey(keyPair.getPublic());
        Date from = new Date();
        Date to = new Date(from.getTime() + 1000L * 24L * 60L * 60L);
        cert.setNotAfter(to);
        cert.setNotBefore(from);
        Security.addProvider(new BouncyCastleProvider());
        cert.setSignatureAlgorithm("SHA1WithRSAEncryption");
        PrivateKey signingKey = keyPair.getPrivate();
        return cert.generate(signingKey, "BC");
    }

    public byte[] exportKeysFromKeystore(String email, String password) throws LoadKeysException, ZipFilesException {
        KeyPair keyPair = loadKeys(email, password);
        return ZipFile.getZIPFromKeyPair(keyPair);
    }
}
