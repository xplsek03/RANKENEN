package cz.mit_consulting.crypto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DecryptedPair {

    byte[] data;
    byte[] metadata;

    public DecryptedPair(byte[] data, byte[] metadata) {
        this.data = data;
        this.metadata = metadata;
    }
}
