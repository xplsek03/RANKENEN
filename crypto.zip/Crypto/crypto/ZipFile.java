package cz.mit_consulting.crypto;

import cz.mit_consulting.exceptions.crypto.CryptographyException;
import cz.mit_consulting.exceptions.filesystem.ZipFilesException;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.security.KeyPair;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZipFile {

    public static final String ZIP_KEY = "key";
    public static final String ZIP_DATA = "data";
    public static final String ZIP_METADATA = "metadata";
    public static final String PRIVATE_KEY = "privatekey";
    public static final String PUBLIC_KEY = "publickey";
    private static final Logger log = Logger.getLogger(ZipFile.class.getName());

    public static HybridEncryptPair getEncryptPairFromZIP(byte[] zip) throws IOException {
        InputStream key = getInputStream(zip, ZIP_KEY);
        InputStream data = getInputStream(zip, ZIP_DATA);
        InputStream metadata = getInputStream(zip, ZIP_METADATA);
        return new HybridEncryptPair(IOUtils.toByteArray(data), IOUtils.toByteArray(metadata), IOUtils.toByteArray(key));
    }

    public static KeyPair getKeyPairFromZIP(byte[] zip, String asymmetricAlgorithm) throws IOException, CryptographyException {
        Crypto crypto = new Crypto();
        InputStream privateKey = getInputStream(zip, PRIVATE_KEY);
        InputStream publicKey = getInputStream(zip, PUBLIC_KEY);
        return new KeyPair(crypto.getPublicKey(IOUtils.toByteArray(publicKey), asymmetricAlgorithm), crypto.getPrivateKey(IOUtils.toByteArray(privateKey), asymmetricAlgorithm));
    }

    public static byte[] getZIPFromEncryptPair(HybridEncryptPair hybridEncryptPair) throws ZipFilesException {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);
            ZipEntry data = new ZipEntry(ZIP_DATA);
            ZipEntry key = new ZipEntry(ZIP_KEY);
            data.setSize(hybridEncryptPair.getData().length);
            key.setSize(hybridEncryptPair.getEncryptedKey().length);
            zos.putNextEntry(data);
            zos.write(hybridEncryptPair.getData());
            zos.putNextEntry(key);
            zos.write(hybridEncryptPair.getEncryptedKey());
            zos.closeEntry();
            zos.close();
            return baos.toByteArray();
        } catch (IOException e) {
            String error = "Cannot make ZIP files from data" + e;
            log.log(Level.SEVERE, error);
            throw new ZipFilesException(error);
        }
    }

    private static InputStream getInputStream(byte[] zip, String entry) throws IOException {
        InputStream targetStream = new ByteArrayInputStream(zip);
        ZipInputStream zin = new ZipInputStream(targetStream);
        for (ZipEntry e; (e = zin.getNextEntry()) != null; ) {
            if (e.getName().equals(entry)) {
                return zin;
            }
        }
        throw new EOFException("Cannot find " + entry);
    }

    public static byte[] getZIPFromDecryptedPair(DecryptedPair decrypted) throws ZipFilesException {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);
            ZipEntry data = new ZipEntry(ZIP_DATA);
            ZipEntry metadata = new ZipEntry(ZIP_METADATA);
            data.setSize(decrypted.getData().length);
            metadata.setSize(decrypted.getMetadata().length);
            zos.putNextEntry(data);
            zos.write(decrypted.getData());
            zos.putNextEntry(metadata);
            zos.write(decrypted.getMetadata());
            zos.closeEntry();
            zos.close();
            return baos.toByteArray();
        } catch (IOException e) {
            String error = "Cannot make ZIP files from data" + e;
            log.log(Level.SEVERE, error);
            throw new ZipFilesException(error);
        }
    }

    public static byte[] getZIPFromKeyPair(KeyPair keyPair) throws ZipFilesException {
        try {
            byte[] privateKeyBytes = keyPair.getPrivate().getEncoded();
            byte[] privateKeyEncoded = Base64.getEncoder().encode(privateKeyBytes);
            byte[] publicKeyBytes = keyPair.getPublic().getEncoded();
            byte[] publicKeyEncoded = Base64.getEncoder().encode(publicKeyBytes);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);
            ZipEntry privateKey = new ZipEntry(PRIVATE_KEY);
            ZipEntry publicKey = new ZipEntry(PUBLIC_KEY);
            privateKey.setSize(privateKeyEncoded.length);
            publicKey.setSize(publicKeyEncoded.length);
            zos.putNextEntry(privateKey);
            zos.write(privateKeyEncoded);
            zos.putNextEntry(publicKey);
            zos.write(publicKeyEncoded);
            zos.closeEntry();
            zos.close();
            return baos.toByteArray();
        } catch (IOException e) {
            String error = "Cannot make ZIP files from data" + e;
            log.log(Level.SEVERE, error);
            throw new ZipFilesException(error);
        }
    }
}
