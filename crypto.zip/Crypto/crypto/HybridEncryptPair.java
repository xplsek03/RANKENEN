package cz.mit_consulting.crypto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HybridEncryptPair {

    byte[] data;
    byte[] metadata;
    byte[] encryptedKey;

    public HybridEncryptPair(byte[] data, byte[] metadatadata, byte[] encryptedKey) {
        this.data = data;
        this.encryptedKey = encryptedKey;
        this.metadata = metadatadata;
    }
}
